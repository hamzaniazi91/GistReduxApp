export const API_BASE_URL = 'https://api.github.com';
export const API_OAUTH = `?client_id=${CLIENT_ID}&client_secret=${CLIENT_SECRET}`;
export const API_URL = `${API_BASE_URL}/users/{username}/gists${API_OAUTH}`;
export const CLIENT_ID = '51539b04ebd5a4df1166';
export const CLIENT_SECRET = '89dada302fbb06528286869d3cf62944732ef741';
